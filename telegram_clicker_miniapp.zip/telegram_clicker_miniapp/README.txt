COIN CLICKER — Telegram Mini App

ЩО Є В ГРІ
- Клік за монети
- Магазин трьох поліпшень
- Автоматичний заробіток, поки гра відкрита
- Локальне збереження прогресу в браузері/Telegram WebView
- Підтримка Telegram Web Apps SDK

ЗАПУСК
1. Створи бота через @BotFather командою /newbot.
2. Увійди на GitHub та створи новий репозиторій, наприклад coin-clicker.
3. Завантаж index.html у корінь репозиторію.
4. Відкрий Settings → Pages. У розділі Build and deployment вибери Deploy from a branch, гілку main і папку /(root), натисни Save.
5. Дочекайся появи URL на кшталт https://USERNAME.github.io/coin-clicker/.
6. Перевір, що URL відкривається через HTTPS.
7. Відкрий @BotFather, введи /setmenubutton, вибери свого бота, введи назву кнопки (наприклад, 🎮 Грати) та встав URL сайту.
8. Відкрий свого бота в Telegram і натисни кнопку меню «🎮 Грати».

ВАЖЛИВО ПРО ЗБЕРЕЖЕННЯ
Ця версія зберігає монети й поліпшення в localStorage на тому самому пристрої/браузері. Очищення даних Telegram або браузера може стерти прогрес. Вона не синхронізує прогрес між різними пристроями й не захищена від редагування з боку гравця.
Для справжнього акаунтного збереження потрібен сервер і перевірка Telegram initData на сервері. Не вставляй токен бота у файл index.html і нікому його не надсилай.

ОФІЦІЙНІ ДОВІДКИ
Telegram Mini Apps: https://core.telegram.org/bots/webapps
GitHub Pages: https://docs.github.com/en/pages
